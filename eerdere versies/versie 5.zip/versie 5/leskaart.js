
// function groeikadermee() {
// const textarea = document.getElementById('antwoord');
// textarea.addEventListener('input', function() {
//   this.style.height = 'auto'; // reset hoogte
//   this.style.height = this.scrollHeight + 'px'; // stel nieuwe hoogte in
// });

// }

// groeikadermee();
