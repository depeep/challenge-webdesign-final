let selectedBlokId = null;
let sortAscending = true;

// Inputs ophalen
const idInput = document.getElementById("id");
const naamInput = document.getElementById("naam");
const gebruikersnaamInput = document.getElementById("gebruikersnaam");
const wachtwoordInput = document.getElementById("wachtwoord");
const actiefInput = document.getElementById("actief");
const result = document.getElementById("result");

const editForm = document.getElementById("editForm");
const editId = document.getElementById("editId");
const editNaam = document.getElementById("editNaam");
const editGebruikersnaam = document.getElementById("editGebruikersnaam");
const editWachtwoord = document.getElementById("editWachtwoord");
const editActief = document.getElementById("editActief");

// VALIDATIE
function validateLeerlingFields(data, isNew=false) {
  const errors = [];
  if (isNew && !data.id) errors.push("ID is verplicht");
  if (!data.naam) errors.push("Naam is verplicht");
  if (!data.gebruikersnaam) errors.push("Gebruikersnaam verplicht");
  if (!data.wachtwoord || data.wachtwoord.length < 6)
    errors.push("Wachtwoord min. 6 tekens");
  if (data.actief !== "1" && data.actief !== "0")
    errors.push("Actief moet '1' of '0' zijn");
  return errors;
}

// SORTEREN
function toggleSort() {
  sortAscending = !sortAscending;
  searchLeerling();
}

// LIVE ZOEKEN
let timer = null;
function liveSearch() {
  clearTimeout(timer);
  timer = setTimeout(() => searchLeerling(), 200);
}

// ZOEKEN
function searchLeerling() {
  const params = new URLSearchParams({
    id: idInput.value,
    naam: naamInput.value,
    gebruikersnaam: gebruikersnaamInput.value,
    wachtwoord: wachtwoordInput.value,
    actief: actiefInput.value
  });

  fetch(`http://localhost:3000/leerlingen?${params}`)
    .then(res => res.json())
    .then(data => {
      // sorteren
      data.sort((a, b) =>
        sortAscending
          ? a.naam.localeCompare(b.naam)
          : b.naam.localeCompare(a.naam)
      );

      if (data.length === 0) {
        result.innerHTML = "Geen leerling gevonden";
        return;
      }

      showResults(data);
    });
}

// resultaten printen
function showResults(data) {
  result.innerHTML = "";

  data.forEach(leerling => {
    const card = document.createElement("div");
    card.className = "card";

    card.innerHTML = `
      <h3>${leerling.naam}</h3>
      <p>
        <strong>ID:</strong> ${leerling.id}<br>
        <strong>naam:</strong> ${leerling.naam}<br>
        <strong>Gebruikersnaam:</strong> ${leerling.gebruikersnaam}<br>
        <strong>Wachtwoord:</strong> ${leerling.wachtwoord}<br>
        <strong>Actief:</strong> ${leerling.actief}
      </p>
    `;

    const editBtn = document.createElement("button");
    editBtn.textContent = "Bewerken";
    editBtn.onclick = () =>editLeerling (leerling.id);

    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "Verwijderen";
    deleteBtn.className = "delete-btn";
    deleteBtn.onclick = () => deleteLeerling(leerling.id);

    card.append(editBtn, deleteBtn);
    result.appendChild(card);
  });
}

// open nieuw formulier
function openNewLeerlingForm() {
  selectedBlokId = null;
  editId.value = "";
  editNaam.value = "";
  editGebruikersnaam.value = "";
  editWachtwoord.value = "";
  editActief.value = "";
  editForm.classList.remove("hidden");
}

function closeEditForm() {
  editForm.classList.add("hidden");
}

// TOEVOEGEN
function addLeerling() {
  const data = {
    id: editId.value,
    naam: editNaam.value,
    gebruikersnaam: editGebruikersnaam.value,
    wachtwoord: editWachtwoord.value,
    actief: String(editActief.value).trim() // zorg dat het een string is
  };

  const errors = validateLeerlingFields(data, true);
  if (errors.length > 0) return alert(errors.join("\n"));

  fetch("http://localhost:3000/leerlingen", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  }).then(() => {
    alert("Toegevoegd!");
    closeEditForm();
    searchLeerling();
  });
}
// BIJWERKEN
function patchLeerling() {
  const data = {
    // id: editId.value.trim(),  //primaire sleutel kan niet aangepast worden, dus niet meesturen
  
    naam: editNaam.value.trim(),
    gebruikersnaam: editGebruikersnaam.value.trim(),
    wachtwoord: editWachtwoord.value.trim(),
    actief: String(editActief.value).trim()
  };

  // verwijder lege velden zodat PATCH correct blijft
  Object.keys(data).forEach(key => {
    if (data[key] === "" || data[key] === undefined) {
      delete data[key];
    }
  });

  fetch(`http://localhost:3000/leerlingen/${selectedBlokId}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  }).then(() => {
    alert("Bijgewerkt!");
    closeEditForm();
    searchLeerling();
  });
}


// DELETE
function deleteLeerling(id) {
  if (!confirm("Weet je zeker dat je deze leerling wilt verwijderen?")) return;

  fetch(`http://localhost:3000/leerlingen/${id}`, {
    method: "DELETE"
  }).then(() => {
    alert("Verwijderd!");
    searchLeerling();
  });
}
//LEERLING EDITEN
function editLeerling(id) {
  selectedBlokId = id;

  editForm.classList.remove("hidden");

  fetch(`http://localhost:3000/leerlingen/${id}`)
    .then(res => res.json())
    .then(leerling => {

      editId.value = leerling.id;
      editNaam.value = leerling.naam;
      editGebruikersnaam.value = leerling.gebruikersnaam;
      editWachtwoord.value = leerling.wachtwoord;
      editActief.value = leerling.actief;

      editForm.classList.remove("hidden");
    });
}


//MOGELIJK BETER OM ASUNC FUNCTIES TE GEBRUIKEN VOOR ADD, PATCH EN DELETE
/*
async function addLeerling() {
  const newLeerling = {
    id: document.getElementById("editId").value.trim(),
    naam: document.getElementById("editNaam").value.trim(),
    gebruikersnaam: document.getElementById("editGebruikersnaam").value.trim(),
    wachtwoord: document.getElementById("editWachtwoord").value.trim(),
    actief: document.getElementById("editActief").value.trim()
  };  
  const errors = validateLeerlingFields(newLeerling, true);
  if (errors.length > 0) return alert(errors.join("\n"));
  try {
    await fetch("http://localhost:3000/leerlingen", {
      method: "POST",
      headers: { "Content-Type": "application/json" },  
      body: JSON.stringify(newLeerling)
    });
    alert("Leerling toegevoegd!");
    closeEditForm();
    searchLeerling();
  } catch {
    alert("Fout bij toevoegen.");
  }   
}

async function patchLeerling() {
  const updated = {
    id: document.getElementById("editId").value.trim(),
    naam: document.getElementById("editNaam").value.trim(),
    gebruikersnaam: document.getElementById("editGebruikersnaam").value.trim(),
    wachtwoord: document.getElementById("editWachtwoord").value.trim(),
    actief: document.getElementById("editActief").value.trim()
  };  
  const errors = validateLeerlingFields(updated);
  if (errors.length > 0) return alert(errors.join("\n"));
  try {
    await fetch(`http://localhost:3000/leerlingen/${selectedBlokId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },  
      body: JSON.stringify(updated)
    });
    alert("Leerling bijgewerkt!");
    closeEditForm();
    searchLeerling();
  } catch {
    alert("Fout bij bijwerken.");
  }   
}

function editLeerling(leerling) {
  selectedBlokId = leerling.id; 
  document.getElementById("editId").value = leerling.id;
  document.getElementById("editNaam").value = leerling.naam;
  document.getElementById("editGebruikersnaam").value = leerling.gebruikersnaam;
  document.getElementById("editWachtwoord").value = leerling.wachtwoord;
  document.getElementById("editActief").value = leerling.actief;
  document.getElementById("editForm").classList.remove("hidden");
} 
function closeEditForm() {
  document.getElementById("editForm").classList.add("hidden");
}
*/
