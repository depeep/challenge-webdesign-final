-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 25 jan 2026 om 21:32
-- Serverversie: 10.4.32-MariaDB
-- PHP-versie: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gamedesign`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `leskaarten`
--

CREATE TABLE `leskaarten` (
  `id` int(11) NOT NULL,
  `titel` text NOT NULL,
  `theorie` text NOT NULL,
  `afb1` text NOT NULL,
  `afb2` text NOT NULL,
  `opdracht` text NOT NULL,
  `extra` text NOT NULL DEFAULT 'leeg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `leskaarten`
--

INSERT INTO `leskaarten` (`id`, `titel`, `theorie`, `afb1`, `afb2`, `opdracht`, `extra`) VALUES
(2, 'Introductie', 'Welkom bij de module gamedesign.<br>\nVoor deze module moet je opdrachten doen op de computer en in dit moduleboekje. De opdrachten zijn te herkennen aan het icoon hiernaast. \nVeel plezier met deze module!', './img/controller-icon.png', '', '', ''),
(3, 'Het gereedschap', 'Voor een timmerman een kast in elkaar kan zetten, moet hij leren hoe hij zijn gereedschappen gebruikt. Het gereedschap dat wij voor deze module gebruiken is Makecode Arcade. In dit eerste deel leer je de basisvaardigheden om een game te maken met dit gereedschap.', './img/makecode.png', './img/signin.png', '<br>1.	Ga naar makecode.com<br> 2.	Kies voor Arcade. <br>3.	Klik op “sign in”(rechtboven)<br>  4.	Maak een account aan met je school-mail. Kies daarvoor “Continue with Microsoft” <br>5.	Scroll naar “Tutorials”<br>    6.	Werk de volgende tutorials door en sla steeds het resultaat op door ze in te vullen in het antwoordveld', 'x'),
(4, 'Tutorial \"intro\"', '', '', './img/tut_intro.png', '<br>\n<b>intro </b><br> \nWerk de tutorial \"intro\" door<br>\nKlik op delen (share), plak de link hieronder en stuur hem in! ', 'x'),
(5, 'Chase the Pizza', '', '', './img/tut_chase.png', '<br>Werk de tutorial \"Chase the Pizza\" door. Als je klaar bent plak je de link naar je resultaat hieronder en lever je hem in met de knop inleveren.', 'x'),
(13, 'Tutorial Collect the Clovers', '', '', './img/tut_collect.png', '<br>Werk de tutorial \"Collect the Clovers\" door. Als je klaar bent plak je de link naar je resultaat hieronder en lever je hem in met de knop inleveren.', 'ja'),
(14, 'Tutorial Dunk', '', '', './img/tut_dunk.png', '<br>Werk de tutorial \"Dunk\" door. Als je klaar bent plak je de link naar je resultaat hieronder en lever je hem in met de knop inleveren.', 'ja'),
(15, 'Tutorial Target Practice', '', '', './img/tut_target.png', '<br>Werk de tutorial \"Target Practice\" door. Als je klaar bent plak je de link naar je resultaat hieronder en lever je hem in met de knop inleveren.', 'z'),
(16, 'Tutorial Galga', '', '', './img/tut_galga.png', '<br>Werk de tutorial \"Galga\" door. Als je klaar bent plak je de link naar je resultaat hieronder en lever je hem in met de knop inleveren.', 'x'),
(17, 'Tutorial Maze', '', '', './img/tut_maze.png', '<br>Werk de tutorial \"Maze\" door. Als je klaar bent plak je de link naar je resultaat hieronder en lever je hem in met de knop inleveren.', 'ja'),
(18, 'Tutorial Side Scroller', '', '', './img/tut_side.png', '<br>Werk de tutorial \"Side Scroller\" door. Als je klaar bent plak je de link naar je resultaat hieronder en lever je hem in met de knop inleveren.', ''),
(19, 'Gametheorie', '<b>Over de gameprincipes van succesvolle games.</b><hr>\nElke goede game bevat een paar belangrijke gameprincipes. In dit onderdeel van de module leer je meer over de vier gameprincipes die onmisbaar zijn voor een goede game:<br><br>\n1.	Duidelijkheid<br>\n2.	Gameflow & leren<br>\n3.	Betrokkenheid<br>\n4.	Beloning<br>\n', '', '', '', ''),
(20, 'Gameprincipe 1: Duidelijkheid', 'In elk spel heb je spelregels die ervoor zorgen dat iedere gamer weet waar hij aan toe is. Alles wat ervoor moet zorgen om een spel succesvol af te ronden en hoeveel punten je daarvoor krijgt, noem je de spelregels. De spelregels worden vaak in het begin van de game duidelijk gemaakt. Dat kan met tekst maar ook vooral met symbolen, pictogrammen en voorbeelden. Je hoeft niet alles in één keer uit te leggen. Met Just In Time informatie (JIT) zorg je ervoor dat er geen overkill aan informatie op één moment komt. Na een paar levels heb je wellicht nieuwe functies in de game, die pas op dat moment uitgelegd worden.<br>\nHet doel van de game is natuurlijk ook van groot belang, het doel moet duidelijk zijn voor de gamer. Dit kan vaak in één heldere zin duidelijk gemaakt worden bijvoorbeeld: \"bevrijd de prinses!\".<br>\nMaak overzicht voor de gamer\n\n', '', '', '', ''),
(21, 'Gameprincipe 2: Gameflow & leren', 'Een populaire term bij gamedevelopers is de gameflow. <br>\nAls een gamer in een bepaalde flow komt is de game leuk en verslavend. Met een goede balans tussen de uitdagingen (challenges) en de gevraagde vaardigheden (skills) raakt de gamer in een gameflow. <br>De game moet dus zo worden ingericht dat het niveau na elk level omhoog gaat, anders wordt het te saai. Maar als het niveau te snel omhoog gaat raakt de gamer gefrustreerd. Nu is die frustratie minder erg dan wanneer het te saai is. Liever iets te moeilijk dan te makkelijk dus.\n<BR><BR>\n<img src= \"./img/flowgrafiek.png\">\n<br><BR>\nFeedback zorgt voor een belangrijke positieve bijdrage aan de ontwikkeling van de skills van de gamer. <br>Hier komen we bij een van de belangrijkste voordelen van een game ten opzichte van een opdracht op papier: <br> In een game krijgt de gamer direct feedback als hij het niet goed doet. De gamer reflecteert supersnel zijn eigen methode en probeert het opnieuw. <br>Dit is erg leerzaam en op die manier ontwikkelt de gamer skills.\n', './img/flowgrafiek.png', '', '', ''),
(22, 'Gameprincipe 3: Betrokkenheid', 'Je kan een geweldig gameconcept hebben bedacht die door het gebrek aan betrokkenheid een toch een flop wordt. Wanneer de gamer zich kan verplaatsen in een bepaald karakter en/of fantasiewereld, zorgt dat automatisch voor meer betrokkenheid. <br>Een goede <b>verhaallijn</b> met een mooi einddoel kan daar aan bijdragen. Men noemt dit RPG spellen, dat staat voor Role Playing Game. Of RPG geschikt is, hangt wel een beetje van het gekozen thema af. Veel populaire spellen hebben geen verhaallijn, denk bijvoorbeeld aan Candy Crush. Daar is een verhaallijn niet echt nodig. Bij de game Villa Elektra is dat anders. De verhaallijn is de rode draad van de game. Dit zorgt voor meer beleving en betrokkenheid.\n<br><br>\n<b>Grafisch</b> moet het kloppen; om een gamer betrokken te houden is het belangrijk dat de game netjes is afgewerkt. Als het grafisch slordig is leidt dat af. Op de website www.opengameart.org vind je wellicht bruikbare (vector) tekeningen voor jouw game.\n<br><br>\nAls jouw gameconcept het toelaat kan een bepaalde vorm van <b>competitie</b> een geweldige meerwaarde zijn. Als gamers een score kunnen behalen en die kunnen vergelijken met anderen, ontstaat er echt een competitiesfeer.<br><br>\nEn dan nog de <b>gamesounds</b>. Een heel belangrijk onderdeel van de game. Speel maar eens een willekeurig spelletje en let dan op de geluidseffecten. Ze zorgen voor veel informatie, feedback en beloning! Een game zonder geluid is als een film zonder geluid. Veel gamedevelopers maken gebruik van de website www.freesound.org. Daar vind je een enorme database van allemaal geluiden. En met het programma Audacity kun je zelf geluidsfragmenten bewerken.\n', '', '', '<br>\nHet Klokhuis heeft over geluid bij games een <a href= \"https://schooltv.nl/video/het-klokhuis-geluid-bij-games/\" target=\"_blank\">aflevering </A> gemaakt.<br>\nBekijk de video en beantwoord de volgende vragen:<br><br>\n1. Hoe noemen we het als een beweging zicht op het scherm telkens herhaalt?\n<br>2. Hoeveel geluidseffecten zitten er volgens het filmpje al gauw in een goede game?\n<br>3. Wat is de reden dat de geluidseffecten niet buiten opgenomen worden, maar in de studio?\n<br>4. \nWat is het grote verschil tussen muziek voor films en muziek voor games?\n\n\n\n', 'ja');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `leskaarten`
--
ALTER TABLE `leskaarten`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `leskaarten`
--
ALTER TABLE `leskaarten`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
