
document.getElementById('dataForm').addEventListener('submit', async function (e) {
    e.preventDefault();

    const inhoud = document.getElementById('inhoud').value;
    const beschrijving = document.getElementById('beschrijving').value;
    const type = document.getElementById('type').value;
    const blokcode = document.getElementById('blokcode').value;

    try {
        const response = await fetch('http://localhost:3000/content', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ inhoud, beschrijving, type, blokcode })
             })
    

        const result = await response.json();
        document.getElementById('response').textContent = `Server antwoord: ${JSON.stringify(result)}`;
    } catch (error) {
        document.getElementById('response').textContent = `Fout: ${error.message}`;
    }
});

// Leegmaken velden na verzenden
inhoud = "";
beschrijving = "";
type = "";
blokcode = "";
document.getElementById('inhoud').value = inhoud;
document.getElementById('beschrijving').value = beschrijving;
document.getElementById('type').value = type;
document.getElementById('blokcode').value = blokcode;   
