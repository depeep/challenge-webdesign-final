let selectedBlokId = null;

function validateLeerlingFields(data, isNew = false) {
  const errors = [];

  if (isNew && !data.id) errors.push("ID mag niet leeg zijn.");
  if (!data.naam) errors.push("Naam is verplicht.");
  if (!data.gebruikersnaam) errors.push("Gebruikersnaam is verplicht.");
  if (!data.wachtwoord || data.wachtwoord.length < 6)
    errors.push("Wachtwoord moet minimaal 6 tekens bevatten.");
  if (data.actief !== "true" && data.actief !== "false")
    errors.push("Actief moet 'true' of 'false' zijn.");

  return errors;
}

async function searchLeerling() {
  const id = document.getElementById("id").value.trim();
  const naam = document.getElementById("naam").value.trim();
  const gebruikersnaam = document.getElementById("gebruikersnaam").value.trim();
  const wachtwoord = document.getElementById("wachtwoord").value.trim();
  const actief = document.getElementById("actief").value.trim();

  const params = new URLSearchParams();
  if (id) params.append("id", id);
  if (naam) params.append("naam", naam);
  if (gebruikersnaam) params.append("gebruikersnaam", gebruikersnaam);
  if (wachtwoord) params.append("wachtwoord", wachtwoord);
  if (actief) params.append("actief", actief);

  const resultContainer = document.getElementById("result");
  resultContainer.innerHTML = "Zoeken...";

  try {
    const response = await fetch(`http://localhost:3000/leerlingen?${params}`);
    const data = await response.json();

    if (data.length === 0) {
      resultContainer.textContent = "Geen leerling gevonden";
      return;
    }

    resultContainer.innerHTML = "";
    data.forEach(leerling => {
      const card = document.createElement("div");
      card.className = "card";
      card.innerHTML = `
        <h3>${leerling.naam}</h3>
        <p>
          <strong>ID:</strong> ${leerling.id}<br>
          <strong>Gebruikersnaam:</strong> ${leerling.gebruikersnaam}<br>
          <strong>Wachtwoord:</strong> ${leerling.wachtwoord}<br>
          <strong>Actief:</strong> ${leerling.actief}
        </p>
      `;

      const editBtn = document.createElement("button");
      editBtn.textContent = "Bewerken";
      editBtn.onclick = () => editLeerling(leerling);

      const deleteBtn = document.createElement("button");
      deleteBtn.textContent = "Verwijderen";
      deleteBtn.className = "delete-btn";
      deleteBtn.onclick = () => deleteLeerling(leerling.id);

      card.append(editBtn, deleteBtn);
      resultContainer.appendChild(card);
    });

  } catch (err) {
    resultContainer.textContent = "Fout bij zoeken.";
  }
}

function editLeerling(leerling) {
  selectedBlokId = leerling.id;

  document.getElementById("editId").value = leerling.id;
  document.getElementById("editNaam").value = leerling.naam;
  document.getElementById("editGebruikersnaam").value = leerling.gebruikersnaam;
  document.getElementById("editWachtwoord").value = leerling.wachtwoord;
  document.getElementById("editActief").value = leerling.actief;

  document.getElementById("editForm").classList.remove("hidden");
}

function closeEditForm() {
  document.getElementById("editForm").classList.add("hidden");
}

async function addLeerling() {
  const newLeerling = {
    id: document.getElementById("editId").value.trim(),
    naam: document.getElementById("editNaam").value.trim(),
    gebruikersnaam: document.getElementById("editGebruikersnaam").value.trim(),
    wachtwoord: document.getElementById("editWachtwoord").value.trim(),
    actief: document.getElementById("editActief").value.trim()
  };

  const errors = validateLeerlingFields(newLeerling, true);
  if (errors.length > 0) return alert(errors.join("\n"));

  try {
    await fetch("http://localhost:3000/leerlingen", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newLeerling)
    });

    alert("Leerling toegevoegd!");
    closeEditForm();
    searchLeerling();

  } catch {
    alert("Fout bij toevoegen.");
  }
}

async function patchLeerling() {
  const updated = {
    id: document.getElementById("editId").value.trim(),
    naam: document.getElementById("editNaam").value.trim(),
    gebruikersnaam: document.getElementById("editGebruikersnaam").value.trim(),
    wachtwoord: document.getElementById("editWachtwoord").value.trim(),
    actief: document.getElementById("editActief").value.trim()
  };

  const errors = validateLeerlingFields(updated);
  if (errors.length > 0) return alert(errors.join("\n"));

  try {
    await fetch(`http://localhost:3000/leerlingen/${selectedBlokId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updated)
    });

    alert("Leerling bijgewerkt!");
    closeEditForm();
    searchLeerling();

  } catch {
    alert("Fout bij bijwerken.");
  }
}

async function deleteLeerling(id) {
  if (!confirm("Weet je zeker dat je deze leerling wilt verwijderen?")) return;

  try {
    await fetch(`http://localhost:3000/leerlingen/${id}`, { method: "DELETE" });
    alert("Leerling verwijderd!");
    searchLeerling();
  } catch {
    alert("Fout bij verwijderen.");
  }
}
