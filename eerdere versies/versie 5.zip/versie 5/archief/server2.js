import express from "express";
import cors from "cors";
import mysql from "mysql2";

const app = express();
app.use(cors());
app.use(express.json());

// MySQL CONNECTIE
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "leerlingenbeheer"
});

db.connect(err => {
  if (err) {
    console.error("MySQL fout:", err);
    return;
  }
  console.log("Verbonden met MySQL!");
});

// --- GET (zoeken) ---
app.get("/leerlingen", (req, res) => {
  let query = "SELECT * FROM leerlingen WHERE 1=1";
  const params = [];

  for (const key of ["id", "naam", "gebruikersnaam", "wachtwoord", "actief"]) {
    if (req.query[key]) {
      query += ` AND ${key} LIKE ?`;
      params.push("%" + req.query[key] + "%");
    }
  }

  db.query(query, params, (err, results) => {
    if (err) return res.status(500).json({ error: err });
    res.json(results);
  });
});

// --- POST (toevoegen) ---
app.post("/leerlingen", (req, res) => {
  const { id, naam, gebruikersnaam, wachtwoord, actief } = req.body;

  db.query(
    "INSERT INTO leerlingen (id, naam, gebruikersnaam, wachtwoord, actief) VALUES (?, ?, ?, ?, ?)",
    [id, naam, gebruikersnaam, wachtwoord, actief],
    err => {
      if (err) return res.status(500).json({ error: err });
      res.json({ message: "Toegevoegd" });
    }
  );
});

// --- PATCH (bewerken) ---
app.patch("/leerlingen/:id", (req, res) => {
  const fields = req.body;
  const keys = Object.keys(fields);

  if (keys.length === 0)
    return res.status(400).json({ error: "Geen velden om bij te werken" });

  const updates = keys.map(k => `${k} = ?`).join(", ");
  const values = keys.map(k => fields[k]);
  values.push(req.params.id);

  db.query(`UPDATE leerlingen SET ${updates} WHERE id = ?`, values, err => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: "Bijgewerkt" });
  });
});

// --- DELETE ---
app.delete("/leerlingen/:id", (req, res) => {
  db.query("DELETE FROM leerlingen WHERE id = ?", [req.params.id], err => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: "Verwijderd" });
  });
});

// SERVER START
app.listen(3000, () => console.log("Server draait op http://localhost:3000"));