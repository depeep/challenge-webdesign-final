function fetchContent() {
  fetch('http://localhost:3000/leskaarten/ALL')
    .then(res => res.json())
    .then(data => {
      const lijst = document.getElementById('leskaartLijst');
      lijst.innerHTML = '';

      data.forEach(contentItem => {
        const div = document.createElement('div');
        div.classList.add('leskaart-item');
        
        div.innerHTML = `
          
          <div class="leskaart-info">
            <h3>${contentItem.id}</h3>
            <p><b>titel:</b> ${contentItem.titel}</p>
            <p><b>theorie:</b>  ${contentItem.theorie}</p>
            <p><b>afb1:</b>  <a href="${contentItem.afb1}" target="_blank"><img src="${contentItem.afb1}" alt="Afbeelding 1"></a></p>
            <p><b>afb2:</b>  <a href="${contentItem.afb2}" target="_blank"><img src="${contentItem.afb2}" alt="Afbeelding 2"></a></p>
            <p><b>opdracht:</b>  ${contentItem.opdracht}</p>
            <p><b>extra:</b>  ${contentItem.extra}</p>
          </div>
        `;


        lijst.appendChild(div);
      });
    });
}

fetchContent ();

// test frontend hiermee haal je data uit de database en laat ze zien

// document.getElementById("boekForm").addEventListener("submit", function(e) {
//   e.preventDefault();

//   const boek = {
//     isbn10: document.getElementById("isbn10").value,
//     titel: document.getElementById("titel").value,
//     auteur: document.getElementById("auteur").value,
//     uitgeverij: document.getElementById("uitgeverij").value,
//     beschrijving: document.getElementById("beschrijving").value,
//     publicatiejaar: document.getElementById("publicatiejaar").value,
//     afbeelding: document.getElementById("afbeelding").value
    
//   };

//   fetch("http://localhost:3000/boeken", {
//     method: "POST",
//     headers: { "Content-Type": "application/json" },
//     body: JSON.stringify(boek)
//   })
//   .then(res => res.json())
//   .then(data => {
//     if (data.success) {
//       document.getElementById("feedback").innerText = "Boek succesvol toegevoegd!";
//       document.getElementById("boekForm").reset();
//       fetchBoeken(); // lijst opnieuw laden
//     } else {
//       document.getElementById("feedback").innerText = "Fout bij toevoegen.";
//     }
//   });
// });

