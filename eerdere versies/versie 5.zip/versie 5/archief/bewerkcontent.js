
let selectedBlokId = null;

async function searchContent() {
  const inhoud = document.getElementById("inhoud").value.trim();
  const beschrijving = document.getElementById("beschrijving").value.trim();
  const type = document.getElementById("type").value.trim();
  const blokcode = document.getElementById("blokcode").value.trim();

  const params = new URLSearchParams();
  if (inhoud) params.append("inhoud", inhoud);
  if (beschrijving) params.append("beschrijving", beschrijving);
  if (type) params.append("type", type);
  if (blokcode) params.append("blokcode", blokcode  );

  const resultContainer = document.getElementById("result");
  resultContainer.innerHTML = "Zoeken...";

  try {
    const response = await fetch(`http://localhost:3000/content?${params.toString()}`);
    if (!response.ok) throw new Error(`Serverfout: ${response.status}`);

    const data = await response.json();

    if (!data || data.length === 0) {   
      resultContainer.textContent = "Geen content gevonden";
      return;
    }

    const container = document.createElement("div");
    container.className = "result-container";

    data.forEach(contentblok => {
      const card = document.createElement("div");
      card.className = "card";      

      
      const inhoud = document.createElement("h3");
      inhoud.textContent = contentblok.inhoud;  
      const inhoudEl = document.createElement("p");
      inhoudEl.innerHTML = `<strong>inhoud:</strong> ${contentblok.inhoud}`;

      const editBtn  = document.createElement("button");
      editBtn.textContent = "Bewerken";
      editBtn.onclick = () => editContent(contentblok);

      const deleteBtn = document.createElement("button");
      deleteBtn.textContent = "Verwijderen";
      deleteBtn.className = "delete-btn";
      deleteBtn.onclick = () => deleteContent (contentblok.id);

      card.append(inhoud, inhoudEl, editBtn, deleteBtn);
      container.appendChild(card);
    });

    resultContainer.innerHTML = "";
    resultContainer.appendChild(container);

    // Velden leegmaken
    document.getElementById("inhoud").value = "";
    document.getElementById("beschrijving").value = "";
    document.getElementById("type").value = "";
    document.getElementById("blokcode").value = "";

  } catch (error) {
    resultContainer.textContent = `Er is een fout opgetreden: ${error.message}`;
  }
}

function editContent(contentblok) {
  selectedBlokId = contentblok.blokid; // Zorg dat je backend een ID teruggeeft
  document.getElementById("editInhoud").value = contentblok.inhoud;
  document.getElementById("editBeschrijving").value = contentblok.beschrijving;
  document.getElementById("editType").value = contentblok.type;
  document.getElementById("editBlokcode").value = contentblok.blokcode;
  document.getElementById("editForm").style.display = "block";
}

async function updateContent() {
  const updatedContent = {
    inhoud: document.getElementById("editInhoud").value,
    beschrijving: document.getElementById("editBeschrijving").value,
    type: document.getElementById("editType").value,
    blokcode: document.getElementById("editBlokcode").value
  };

  try {
    const response = await fetch(`http://localhost:3000/content/${blokId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedContent)
    });

    if (!response.ok) throw new Error("Fout bij opslaan");
    alert("Content succesvol bijgewerkt!");
    document.getElementById("editForm").style.display = "none";
    searchContent(); // herlaad de lijst
  } catch (error) {
    alert("Er is een fout opgetreden: " + error.message);
  }
}

//nieuwe functie patchBook, vervangt updateBook, stuurt alleen velden die niet leeg zijn naar de backend
//misschien ook te gebruiken bij ophogen van exemplaren
async function patchContent() {
  const updatedFields = {};

  // Voeg alleen velden toe die niet leeg zijn
  const inhoud = document.getElementById("editInhoud").value.trim();
  const beschrijving = document.getElementById("editBeschrijving").value.trim();
  const type = document.getElementById("editType").value.trim();
  const blokcode = document.getElementById("editBlokcode").value.trim();

  if (inhoud) updatedFields.inhoud = inhoud;
  if (beschrijving) updatedFields.beschrijving = beschrijving;
  if (type) updatedFields.type = type;
  if (blokcode) updatedFields.blokcode = blokcode;
 
  try {
    const response = await fetch(`http://localhost:3000/content/${selectedBlokId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedFields)
    });

    if (!response.ok) throw new Error("Fout bij gedeeltelijke update");
    alert("Content succesvol gedeeltelijk bijgewerkt!");
    document.getElementById("editForm").style.display = "none";
    searchContent(); // herlaad de lijst
  } catch (error) {
    alert("Er is een fout opgetreden: " + error.message);
  }
}

/*
async function deleteBook(bookId) {
  if (!confirm("Weet je zeker dat je dit boek wilt verwijderen?")) return;

  try {
    const response = await fetch(`http://localhost:3000/boeken/${bookId}`, {
      method: "DELETE"
    });

    if (!response.ok) throw new Error("Fout bij verwijderen");
    alert("Boek succesvol verwijderd!");
    searchBook(); // herlaad de lijst
  } catch (error) {
    alert("Er is een fout opgetreden: " + error.message);
  }
}

// Enter-toets activeren
["isbnInput", "titelInput", "auteurInput"].forEach(id => {
  document.getElementById(id).addEventListener("keydown", e => {
    if (e.key === "Enter") searchBook();
  });
});
*/