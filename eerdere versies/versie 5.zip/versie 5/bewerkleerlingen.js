
let selectedBlokId = null;

async function searchleerling() {
  const id = document.getElementById("id").value.trim();
  const naam = document.getElementById("naam").value.trim();
  const gebruikersnaam = document.getElementById("gebruikersnaam").value.trim();
  const wachtwoord = document.getElementById("wachtwoord").value.trim();
  const actief = document.getElementById("actief").value.trim();

  const params = new URLSearchParams();
  if (id) params.append("id", id);
  if (naam) params.append("naam", naam);
  if (gebruikersnaam) params.append("gebruikersnaam", gebruikersnaam);
  if (wachtwoord) params.append("wachtwoord", wachtwoord);
  if (actief) params.append("actief", actief);

  const resultContainer = document.getElementById("result");
  resultContainer.innerHTML = "Zoeken...";

  try {
    const response = await fetch(`http://localhost:3000/leerlingen?${params.toString()}`);
    if (!response.ok) throw new Error(`Serverfout: ${response.status}`);

    const data = await response.json();

    if (!data || data.length === 0) {   
      resultContainer.textContent = "Geen leerling gevonden";
      return;
    }

    const container = document.createElement("div");
    container.className = "result-container";

    data.forEach(contentblok => {
      const card = document.createElement("div");
      card.className = "card";      

      
      const inhoud = document.createElement("h3");
      inhoud.textContent = contentblok.inhoud;  
      const inhoudEl = document.createElement("p");
      inhoudEl.innerHTML = `<strong>id:</strong> ${contentblok.id}<br>
                            <strong>naam:</strong> ${contentblok.naam}<br>
                            <strong>gebruikersnaam:</strong> ${contentblok.gebruikersnaam}<br>
                            <strong>wachtwoord:</strong> ${contentblok.wachtwoord}<br>
                            <strong>actief:</strong> ${contentblok.actief}<br>`;

      const editBtn  = document.createElement("button");
      editBtn.textContent = "Bewerken";
      editBtn.onclick = () => editLeerling(contentblok);

      const deleteBtn = document.createElement("button");
      deleteBtn.textContent = "Verwijderen";
      deleteBtn.className = "delete-btn";
      deleteBtn.onclick = () => deleteLeerling (contentblok.id);

      card.append(inhoud, inhoudEl, editBtn, deleteBtn);
      container.appendChild(card);
    });

    resultContainer.innerHTML = "";
    resultContainer.appendChild(container);

    // Velden leegmaken
    document.getElementById("id").value = "";
    document.getElementById("naam").value = "";
    document.getElementById("gebruikersnaam").value = "";
    document.getElementById("wachtwoord").value = "";
    document.getElementById("actief").value = "";

  } catch (error) {
    resultContainer.textContent = `Er is een fout opgetreden: ${error.message}`;
  }
}

function editLeerling(contentblok) {
  selectedBlokId = contentblok.blokid; // Zorg dat je backend een ID teruggeeft
  document.getElementById("editId").value = contentblok.id;
  document.getElementById("editNaam").value = contentblok.naam;
  document.getElementById("editGebruikersnaam").value = contentblok.gebruikersnaam;
  document.getElementById("editWachtwoord").value = contentblok.wachtwoord;
  document.getElementById("editActief").value = contentblok.actief;
  document.getElementById("editForm").style.display = "block";
}
/*
async function updateLeerling()) {
  const updatedLeerling = {
    inhoud: document.getElementById("editId").value,
    beschrijving: document.getElementById("editNaam").value,
    type: document.getElementById("editGebruikersnaam").value,
    blokcode: document.getElementById("editWachtwoord").value,  
    actief: document.getElementById("editActief").value
  };

  try {
    const response = await fetch(`http://localhost:3000/leerlingen/${blokId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedContent)
    });

    if (!response.ok) throw new Error("Fout bij opslaan");
    alert("Content succesvol bijgewerkt!");
    document.getElementById("editForm").style.display = "none";
    searchContent(); // herlaad de lijst
  } catch (error) {
    alert("Er is een fout opgetreden: " + error.message);
  }
}
*/
//nieuwe functie patchBook, vervangt updateBook, stuurt alleen velden die niet leeg zijn naar de backend
//misschien ook te gebruiken bij ophogen van exemplaren
async function patchLeerling() {
  const updatedFields = {};

  // Voeg alleen velden toe die niet leeg zijn
  const id = document.getElementById("editId").value.trim();
  const naam = document.getElementById("editNaam").value.trim();
  const gebruikersnaam = document.getElementById("editGebruikersnaam").value.trim();
  const wachtwoord = document.getElementById("editWachtwoord").value.trim();
  const actief = document.getElementById("editActief").value.trim();

  if (id) updatedFields.id = id;
  if (naam) updatedFields.naam = naam;
  if (gebruikersnaam) updatedFields.gebruikersnaam = gebruikersnaam;
  if (wachtwoord) updatedFields.wachtwoord = wachtwoord;
  if (actief) updatedFields.actief = actief;

  try {
    const response = await fetch(`http://localhost:3000/leerlingen/${selectedBlokId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedFields)
    });

    if (!response.ok) throw new Error("Fout bij gedeeltelijke update");
    alert("Leerling succesvol gedeeltelijk bijgewerkt!");
    document.getElementById("editForm").style.display = "none";
    searchContent(); // herlaad de lijst
  } catch (error) {
    alert("Er is een fout opgetreden: " + error.message);
  }
}

/*
async function deleteBook(bookId) {
  if (!confirm("Weet je zeker dat je dit boek wilt verwijderen?")) return;

  try {
    const response = await fetch(`http://localhost:3000/boeken/${bookId}`, {
      method: "DELETE"
    });

    if (!response.ok) throw new Error("Fout bij verwijderen");
    alert("Boek succesvol verwijderd!");
    searchBook(); // herlaad de lijst
  } catch (error) {
    alert("Er is een fout opgetreden: " + error.message);
  }
}

// Enter-toets activeren
["isbnInput", "titelInput", "auteurInput"].forEach(id => {
  document.getElementById(id).addEventListener("keydown", e => {
    if (e.key === "Enter") searchBook();
  });
});
*/