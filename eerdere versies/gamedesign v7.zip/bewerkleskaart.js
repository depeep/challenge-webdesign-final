

// Haal het id uit de querystring
const params = new URLSearchParams(window.location.search);
const id = params.get('id');



async function getLeskaart() {
  try {
    const response = await fetch(`http://localhost:3000/leskaarten/${id}`);
    const data = await response.json();
    console.log('Leskaart data:', data);
    // Vul hier je HTML met de data
    document.getElementById('titel').value = data[0].titel;
    document.getElementById('theorie').value = data[0].theorie;
    document.getElementById('afb1').value = data[0].afb1;
    document.getElementById('afb2').value = data[0].afb2;
    document.getElementById('opdracht').value = data[0].opdracht;
    document.getElementById('extra').value = data[0].extra;

  } catch (error) {
    console.error('Fout bij ophalen:', error);
  }
}

// Event listener voor de update knop
document.getElementById('update-knop').addEventListener('click', () => {
    const titel = document.getElementById('titel').value;
    const theorie = document.getElementById('theorie').value;
    const afb1 = document.getElementById('afb1').value;
    const afb2 = document.getElementById('afb2').value;
    const opdracht = document.getElementById('opdracht').value;
    const extra = document.getElementById('extra').value;       

    updateLeskaart({ titel, theorie, afb1, afb2, opdracht, extra });
});

// // Event listener voor de verwijder knop, verplaatst naar overzicht.js
// document.getElementById('verwijder-knop').addEventListener('click', () => {
//     deleteLeskaart(id);
// });




getLeskaart();

async function updateLeskaart(fields) {
  try {
    const response = await fetch(`http://localhost:3000/leskaarten/${id}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(fields)
    });

    if (!response.ok) throw new Error('Fout bij updaten');

    alert('Leskaart succesvol bijgewerkt!');
    // Optioneel: herlaad de pagina of ga terug naar het overzicht
    window.location.href = './overzicht.html';
  } catch (error) {
    alert('Fout bij updaten: ' + error.message);
  }
}

/* Verwijder leskaart functie is verplaatst naar overzicht.js */
/*
async function deleteLeskaart(id) {
  if (!confirm("Weet je zeker dat je deze leskaart wilt verwijderen?")) return;

  try {
    const response = await fetch(`http://localhost:3000/leskaarten/${id}`, {
      method: "DELETE"
    });

    if (!response.ok) throw new Error("Fout bij verwijderen");
    alert("Leskaart succesvol verwijderd!");
    searchBook(); // herlaad de lijst
  } catch (error) {
    alert("Er is een fout opgetreden: " + error.message);
  }
}
*/

// async function searchBook() {
//     const container = document.createElement("div");
//     container.className = "result-container";

//     data.forEach(book => {
//       const card = document.createElement("div");
//       card.className = "card";

//       const img = document.createElement("img");
//       img.src = book.afbeelding;
//       img.alt = book.titel;

//       const title = document.createElement("h3");
//       title.textContent = book.titel;

//       const auteurEl = document.createElement("p");
//       auteurEl.innerHTML = `<strong>Auteur:</strong> ${book.auteur}`;

//       const editBtn = document.createElement("button");
//       editBtn.textContent = "Bewerken";
//       editBtn.onclick = () => editBook(book);

//       const deleteBtn = document.createElement("button");
//       deleteBtn.textContent = "Verwijderen";
//       deleteBtn.className = "delete-btn";
//       deleteBtn.onclick = () => deleteBook(book.id);

//       card.append(img, title, auteurEl, editBtn, deleteBtn);
//       container.appendChild(card);
//     });

//     resultContainer.innerHTML = "";
//     resultContainer.appendChild(container);

//     // Velden leegmaken
//     document.getElementById("isbnInput").value = "";
//     document.getElementById("titelInput").value = "";
//     document.getElementById("auteurInput").value = "";

//   } catch (error) {
//     resultContainer.textContent = `Er is een fout opgetreden: ${error.message}`;
//   }
// }
// **************************

// function editBook(book) {
//   selectedBookId = book.id; // Zorg dat je backend een ID teruggeeft
//   document.getElementById("editTitel").value = book.titel;
//   document.getElementById("editAuteur").value = book.auteur;
//   document.getElementById("editUitgeverij").value = book.uitgeverij;
//   document.getElementById("editJaar").value = book.publicatiejaar;
//   document.getElementById("editExemplaren").value = book.exemplaren;

//   document.getElementById("editForm").style.display = "block";
// }

// async function updateBook() {
//   const updatedBook = {
//     titel: document.getElementById("editTitel").value,
//     auteur: document.getElementById("editAuteur").value,
//     uitgeverij: document.getElementById("editUitgeverij").value,
//     publicatiejaar: document.getElementById("editJaar").value,
//     exemplaren: document.getElementById("editExemplaren").value
//   };

//   try {
//     const response = await fetch(`http://localhost:3000/boeken/${selectedBookId}`, {
//       method: "PUT",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(updatedBook)
//     });

//     if (!response.ok) throw new Error("Fout bij opslaan");
//     alert("Boek succesvol bijgewerkt!");
//     document.getElementById("editForm").style.display = "none";
//     searchBook(); // herlaad de lijst
//   } catch (error) {
//     alert("Er is een fout opgetreden: " + error.message);
//   }
// }
// // ****************************************************************
// //nieuwe functie patchLeskaart, vervangt updateBook, stuurt alleen velden die niet leeg zijn naar de backend
// //misschien ook te gebruiken bij ophogen van exemplaren
// async function patchLeskaart() {
//   const updatedFields = {};

//   // Voeg alleen velden toe die niet leeg zijn
//   const titel = document.getElementById("editTitel").value.trim();
//   const auteur = document.getElementById("editAuteur").value.trim();
//   const uitgeverij = document.getElementById("editUitgeverij").value.trim();
//   const jaar = document.getElementById("editJaar").value.trim();
//   const exemplaren = document.getElementById("editExemplaren").value.trim();

//   if (titel) updatedFields.titel = titel;
//   if (auteur) updatedFields.auteur = auteur;
//   if (uitgeverij) updatedFields.uitgeverij = uitgeverij;
//   if (jaar) updatedFields.publicatiejaar = jaar;
//   if (exemplaren) updatedFields.exemplaren = exemplaren;

//   try {
//     const response = await fetch(`http://localhost:3000/leskaarten/${selectedBookId}`, {
//       method: "PATCH",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(updatedFields)
//     });

//     if (!response.ok) throw new Error("Fout bij gedeeltelijke update");
//     alert("Boek succesvol gedeeltelijk bijgewerkt!");
//     document.getElementById("editForm").style.display = "none";
//     searchBook(); // herlaad de lijst
//   } catch (error) {
//     alert("Er is een fout opgetreden: " + error.message);
//   }
// }


// async function deleteBook(bookId) {
//   if (!confirm("Weet je zeker dat je dit boek wilt verwijderen?")) return;

//   try {
//     const response = await fetch(`http://localhost:3000/boeken/${bookId}`, {
//       method: "DELETE"
//     });

//     if (!response.ok) throw new Error("Fout bij verwijderen");
//     alert("Boek succesvol verwijderd!");
//     searchBook(); // herlaad de lijst
//   } catch (error) {
//     alert("Er is een fout opgetreden: " + error.message);
//   }
// }

// // Enter-toets activeren
// ["isbnInput", "titelInput", "auteurInput"].forEach(id => {
//   document.getElementById(id).addEventListener("keydown", e => {
//     if (e.key === "Enter") searchBook();
//   });
// });
