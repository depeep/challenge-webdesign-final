import express from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import mysql from "mysql2/promise";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();
const app = express();

app.use(cors());
app.use(express.json());

// DATABASE VERBINDING ----------------------------
const db = await mysql.createConnection({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASS || "xampp-root",
  database: process.env.DB_NAME || "gamedesign"
});

console.log("Verbonden met MySQL database");


// ------------------------------
// REGISTRATIE / LOGIN
// ------------------------------

app.post("/register", async (req, res) => {
  const { email, password, naam, rol } = req.body;

  const hashed = await bcrypt.hash(password, 12);

  await db.query(
    "INSERT INTO users (email, password_hash, naam, rol) VALUES (?, ?, ?, ?)",
    [email, hashed, naam, rol || "leerling"] 
  );

  res.json({ message: "Gebruiker geregistreerd" });
});

app.post("/login", async (req, res) => {
  const { email, password } = req.body;

  const [rows] = await db.query("SELECT * FROM users WHERE email = ?", [email]);
  if (rows.length === 0)
    return res.status(400).json({ error: "Onbekend e-mail" });

  const user = rows[0];
  const valid = await bcrypt.compare(password, user.password_hash);

  if (!valid) return res.status(401).json({ error: "Wachtwoord onjuist" });
//id, naam, rol meegeven in token
const token = jwt.sign(
  { id: user.id, naam: user.naam, rol: user.rol },
  process.env.JWT_SECRET,
  { expiresIn: "1h" }
);

  res.json({ token });
});


// ------------------------------
// AUTH MIDDLEWARE (optioneel)
// ------------------------------
function auth(req, res, next) {
  const header = req.headers.authorization;
  if (!header) return res.status(401).json({ error: "Geen token" });

  const token = header.split(" ")[1];
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    return res.status(403).json({ error: "Ongeldige token" });
  }
}

// middleware om rol te controleren voor bepaalde routes
// gebruik: app.get("/admin", auth, requireRole("admin"), (req, res) => { ... });
// voorbeeld auth, requireRole("docent"), zoals hieronder bij get("/leerlingen")

function requireRole(rol) {
  return (req, res, next) => {
    if (!req.user || req.user.rol !== rol) {
      return res.status(403).json({ error: "Geen toegang (rol vereist)" });
    }
    next();
  };
}


// ------------------------------
// PROFILE (beschermd)
// ------------------------------
app.get("/profile", auth, (req, res) => {
  res.json({
    message: "Welkom!",
    naam: req.user.naam,
    userId: req.user.id,
    rol: req.user.rol
  });
});


// ------------------------------
// LESKAARTEN CRUD
// ------------------------------

app.get("/leskaarten/ALL", async (req, res) => {
  const [rows] = await db.query("SELECT * FROM leskaarten");
  res.json(rows);
});

app.get("/leskaarten/:id", async (req, res) => {
  const [rows] = await db.query("SELECT * FROM leskaarten WHERE id = ?", [
    req.params.id
  ]);
  res.json(rows);
});

app.post("/leskaarten", async (req, res) => {
  const { titel, theorie, afb1, afb2, opdracht, extra } = req.body;

  const sql = `
    INSERT INTO leskaarten (titel, theorie, afb1, afb2, opdracht, extra)
    VALUES (?, ?, ?, ?, ?, ?)
  `;

  const [result] = await db.query(sql, [
    titel,
    theorie,
    afb1,
    afb2,
    opdracht,
    extra
  ]);

  res.json({ success: true, id: result.insertId });
});

app.patch("/leskaarten/:id", async (req, res) => {
  const fields = req.body;
  if (!Object.keys(fields).length)
    return res.status(400).json({ message: "Geen velden om bij te werken" });

  const keys = Object.keys(fields).map((k) => `${k} = ?`).join(", ");
  const values = [...Object.values(fields), req.params.id];

  await db.query(`UPDATE leskaarten SET ${keys} WHERE id = ?`, values);
  res.json({ message: "Leskaart bijgewerkt" });
});

app.delete("/leskaarten/:id", async (req, res) => {
  await db.query("DELETE FROM leskaarten WHERE id = ?", [req.params.id]);
  res.json({ message: "Leskaart verwijderd" });
});


// ------------------------------
// LEERLINGEN CRUD
// ------------------------------

app.get("/leerlingen",auth, requireRole("docent"), async (req, res) => {
  let query = "SELECT * FROM leerlingen WHERE 1=1";
  const params = [];

  for (const key of ["id", "naam", "gebruikersnaam", "wachtwoord", "actief"]) {
    if (req.query[key]) {
      query += ` AND ${key} LIKE ?`;
      params.push(`%${req.query[key]}%`);
    }
  }

  const [rows] = await db.query(query, params);
  res.json(rows);
});

app.post("/leerlingen", async (req, res) => {
  const { id, naam, gebruikersnaam, wachtwoord, actief } = req.body;

  await db.query(
    "INSERT INTO leerlingen (id, naam, gebruikersnaam, wachtwoord, actief) VALUES (?, ?, ?, ?, ?)",
    [id, naam, gebruikersnaam, wachtwoord, actief]
  );

  res.json({ message: "Toegevoegd" });
});

app.patch("/leerlingen/:id", async (req, res) => {
  const fields = req.body;

  const updates = Object.keys(fields)
    .map((k) => `${k} = ?`)
    .join(", ");

  const values = [...Object.values(fields), req.params.id];

  await db.query(`UPDATE leerlingen SET ${updates} WHERE id = ?`, values);
  res.json({ message: "Bijgewerkt" });
});

app.delete("/leerlingen/:id", async (req, res) => {
  await db.query("DELETE FROM leerlingen WHERE id = ?", [req.params.id]);
  res.json({ message: "Verwijderd" });
});

// antwoorden van leerlingen opslaan
/*
app.post("/antwoorden", async (req, res) => {
  const { leerlingId, leskaartId, antwoord } = req.body;    
  await db.query(
    "INSERT INTO antwoorden (leerlingId, leskaartId, antwoord) VALUES (?, ?, ?)",
    [leerlingId, leskaartId, antwoord]
  );
  res.json({ message: "Antwoord opgeslagen" });
}
);
*/

app.post("/antwoorden", auth, async (req, res) => {
  const { leskaartenid, antwoord } = req.body;

  // user-id halen uit token
  const usersid = req.user.id;

  if (!leskaartenid || !antwoord) {
    return res.status(400).json({ error: "leskaartenid en antwoord zijn verplicht" });
  }

  try {
    const sql = `
      INSERT INTO antwoorden (usersid, leskaartenid, antwoord)
      VALUES (?, ?, ?)
    `;

    const [result] = await db.query(sql, [usersid, leskaartenid, antwoord]);

    res.json({
      success: true,
      insertedId: result.insertId
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Database fout" });
  }
});







// ------------------------------
// START SERVER
// ------------------------------

app.listen(3000, () => console.log("Server draait op http://localhost:3000"));