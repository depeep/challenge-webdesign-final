voor de benodigde bibliotheken om veilig in te loggen:

npm init -y
npm install express bcrypt jsonwebtoken mysql2 dotenv cors

