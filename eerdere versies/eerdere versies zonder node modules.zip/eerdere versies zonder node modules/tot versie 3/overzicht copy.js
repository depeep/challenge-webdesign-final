function fetchContent() {
  fetch('http://localhost:3000/leskaarten/ALL')
    .then(res => res.json())
    .then(data => {
      const lijst = document.getElementById('leskaartLijst');
      lijst.innerHTML = '';

      data.forEach(contentItem => {
        const div = document.createElement('div');
                div.classList.add('leskaart-item');
        
       
        div.innerHTML = `
          
        
          <section class="leskaart">
          <div id="titel" class="kaart">
            <h1>${contentItem.titel}</h1>
          </div>

          <!-- Theorie + Afbeeldingen samen in één kader -->
          <div id="theorie-met-afbeeldingen" class="kaart">
            <div class="theorie-tekst">
              ${contentItem.theorie}
            </div>
        
            <div class="afbeeldingen-container">
            
              <div id="afbeelding1" class="afbeelding"><img src="${contentItem.afb1}" alt="Afbeelding 1"></div>

            </div>
            </div>`;

        // if (contentItem.afb2 !== 'x') {
        //   div.innerHTML += `
        //       <div id="afbeelding2" class="afbeelding"><img src="${contentItem.afb2}" alt="Afbeelding 2"></div>
        //    `
        //   ; };

    
        

       
      if (contentItem.opdracht !== 'x') {
        div.innerHTML += `
          <div id="opdracht-met-afbeeldingen" class="kaart">
            <div class="opdracht-container">
              <div class="opdracht-tekst">
                <img class="icoon" src="./img/controller-icon.png" alt="Controller icoon" /><br>
                ${contentItem.opdracht}
              </div>
        `;

        if (contentItem.afb2 !== 'x') {
          div.innerHTML += `
              <div class="afbeelding">
                <img src="${contentItem.afb2}" alt="Afbeelding 2">
              </div>
          `;
        }

        div.innerHTML += `
            </div> <!-- sluit opdracht-container -->
          </div>
          <div id="antwoord" class="kaart">
            <label for="antwoord">Antwoord:</label>
            <textarea class="input" id="antwoord" placeholder="Typ hier je antwoord..."></textarea>
          </div>
        `;
      }


        div.innerHTML += `</section>`;  

         
        

       
        lijst.appendChild(div); 
      });
    });
}


fetchContent ();


